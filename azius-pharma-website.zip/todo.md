# Azius Pharma Pvt. Ltd. Website - TODO

## Public-Facing Pages
- [x] Home page with hero section and company highlights
- [x] Products page with product catalog display
- [x] Product detail page with full product information
- [x] About Us page with company information
- [x] Contact page with company information
- [x] Navigation header/footer across all pages

## Product Catalog Features
- [x] Display products with name, description, category, and image
- [x] Product search functionality
- [x] Category filtering on products page
- [x] Product detail view with full information

## Admin Panel
- [x] Role-protected admin dashboard (admin-only access)
- [x] Admin products management page
- [x] Add product functionality
- [x] Edit product functionality
- [x] Delete product functionality
- [x] Product image upload to S3
- [x] Display uploaded images in admin panel

## Database & API
- [x] Products table schema
- [x] Database query helpers for products
- [x] tRPC procedures for product CRUD operations
- [x] tRPC procedures for product search and filtering
- [x] tRPC procedure for product image upload to S3

## Design & Styling
- [x] Establish premium design tokens and color palette
- [x] Set up typography system
- [x] Create reusable UI components
- [x] Ensure responsive design across all pages
- [x] Apply polished, elegant aesthetic throughout

## Testing & Verification
- [x] Test product CRUD operations
- [x] Test image upload to S3
- [x] Verify images display correctly on public pages
- [x] Test search and filtering functionality
- [x] Verify admin panel access control
- [x] Test responsive design on mobile/tablet/desktop

## PDF Product Integration
- [x] Extract and save product images from PDF to S3
- [x] Delete existing test products from database
- [x] Insert 5 new products from PDF with complete details
- [x] Verify all products display correctly in catalog
- [x] Implement homepage product slideshow
- [x] Test slideshow functionality and animations
- [x] Verify product images render correctly in slideshow

## Job Vacancy Management System
- [x] Update database schema with jobs and applications tables
- [x] Add database query helpers for job management
- [x] Add tRPC procedures for job CRUD operations
- [x] Add tRPC procedure for job applications
- [x] Create admin job management interface
- [x] Create public job listings page
- [x] Create job detail page with application form
- [x] Test job creation, editing, and deletion
- [x] Test job application functionality
- [x] Verify admin-only access control for job management

## Branding & Logo
- [x] Upload Azius logo to S3 storage
- [x] Integrate logo in header
- [x] Integrate logo in footer

## Company Settings Management
- [x] Create company_settings table in database
- [x] Add database query helpers for settings
- [x] Add tRPC procedures for reading/updating settings
- [x] Create admin settings management interface
- [x] Update Footer to use dynamic company information
- [x] Update Contact page to use dynamic company information
- [x] Test settings updates and display across website

## Video Management System
- [x] Create videos table in database
- [x] Upload promotional video to S3
- [x] Add database query helpers for videos
- [x] Add tRPC procedures for video CRUD operations
- [x] Create admin video management interface
- [x] Display video on home page right side
- [x] Test video playback and admin controls
