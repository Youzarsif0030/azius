import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, adminProcedure } from "./_core/trpc";
import { z } from "zod";
import { getAllProducts, getProductById, getProductsByCategory, searchProducts, createProduct, updateProduct, deleteProduct, getAllJobs, getJobById, getOpenJobs, searchJobs, createJob, updateJob, deleteJob, createJobApplication, getApplicationsByJobId, updateJobApplication, getCompanySettings, updateCompanySettings, getVideos, getAllVideos, createVideo, updateVideo, deleteVideo } from "./db";
import { storagePut } from "./storage";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  products: router({
    // Public procedures
    list: publicProcedure.query(() => getAllProducts()),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(({ input }) => getProductById(input.id)),

    getByCategory: publicProcedure
      .input(z.object({ category: z.string() }))
      .query(({ input }) => getProductsByCategory(input.category)),

    search: publicProcedure
      .input(z.object({ query: z.string() }))
      .query(({ input }) => searchProducts(input.query)),

    // Admin procedures
    create: adminProcedure
      .input(z.object({
        name: z.string().min(1),
        description: z.string().optional(),
        category: z.string().min(1),
      }))
      .mutation(({ input }) => createProduct(input)),

    update: adminProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        description: z.string().optional(),
        category: z.string().optional(),
        imageUrl: z.string().optional(),
      }))
      .mutation(({ input }) => {
        const { id, ...updates } = input;
        return updateProduct(id, updates);
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => deleteProduct(input.id)),

    uploadImage: adminProcedure
      .input(z.object({
        productId: z.number(),
        imageData: z.string(),
        fileName: z.string(),
      }))
      .mutation(async ({ input }) => {
        try {
          const buffer = Buffer.from(input.imageData.split(',')[1] || input.imageData, 'base64');
          const fileKey = `products/${input.productId}-${Date.now()}-${input.fileName}`;
          const { url } = await storagePut(fileKey, buffer, 'image/jpeg');
          await updateProduct(input.productId, { imageUrl: url });
          return { success: true, url };
        } catch (error) {
          console.error('Image upload failed:', error);
          throw new Error('Failed to upload image');
        }
      }),
  }),

  jobs: router({
    // Public procedures
    list: publicProcedure.query(() => getAllJobs()),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(({ input }) => getJobById(input.id)),

    getOpen: publicProcedure.query(() => getOpenJobs()),

    search: publicProcedure
      .input(z.object({ query: z.string() }))
      .query(({ input }) => searchJobs(input.query)),

    // Admin procedures
    create: adminProcedure
      .input(z.object({
        title: z.string().min(1),
        description: z.string().min(1),
        department: z.string().min(1),
        location: z.string().min(1),
        salary: z.string().optional(),
        jobType: z.enum(["Full-time", "Part-time", "Contract", "Internship"]),
        experience: z.string().optional(),
        qualifications: z.string().optional(),
        responsibilities: z.string().optional(),
      }))
      .mutation(({ input }) => createJob(input)),

    update: adminProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        department: z.string().optional(),
        location: z.string().optional(),
        salary: z.string().optional(),
        jobType: z.enum(["Full-time", "Part-time", "Contract", "Internship"]).optional(),
        experience: z.string().optional(),
        qualifications: z.string().optional(),
        responsibilities: z.string().optional(),
        status: z.enum(["Open", "Closed", "On Hold"]).optional(),
      }))
      .mutation(({ input }) => {
        const { id, ...updates } = input;
        return updateJob(id, updates);
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => deleteJob(input.id)),

    // Job Applications
    submitApplication: publicProcedure
      .input(z.object({
        jobId: z.number(),
        fullName: z.string().min(1),
        email: z.string().email(),
        phone: z.string().min(1),
        resume: z.string().optional(),
        coverLetter: z.string().optional(),
      }))
      .mutation(({ input, ctx }) => {
        return createJobApplication({
          jobId: input.jobId,
          userId: ctx.user?.id || 0,
          fullName: input.fullName,
          email: input.email,
          phone: input.phone,
          resume: input.resume,
          coverLetter: input.coverLetter,
        });
      }),

    getApplications: adminProcedure
      .input(z.object({ jobId: z.number() }))
      .query(({ input }) => getApplicationsByJobId(input.jobId)),

    updateApplicationStatus: adminProcedure
      .input(z.object({
        applicationId: z.number(),
        status: z.enum(["Applied", "Reviewing", "Shortlisted", "Rejected", "Accepted"]),
      }))
      .mutation(({ input }) => updateJobApplication(input.applicationId, { status: input.status })),
  }),

  settings: router({
    get: publicProcedure.query(() => getCompanySettings()),

    update: adminProcedure
      .input(z.object({
        companyName: z.string().optional(),
        email: z.string().email().optional(),
        phone: z.string().optional(),
        address: z.string().optional(),
        city: z.string().optional(),
        state: z.string().optional(),
        country: z.string().optional(),
        zipCode: z.string().optional(),
        website: z.string().optional(),
        description: z.string().optional(),
      }))
      .mutation(({ input }) => updateCompanySettings(input)),
  }),

  videos: router({
    // Public procedures
    list: publicProcedure.query(() => getVideos()),

    // Admin procedures
    all: adminProcedure.query(() => getAllVideos()),

    create: adminProcedure
      .input(z.object({
        title: z.string().min(1),
        description: z.string().optional(),
        videoUrl: z.string().min(1),
        thumbnailUrl: z.string().optional(),
        displayOrder: z.number().optional(),
        isActive: z.enum(["true", "false"]).optional(),
      }))
      .mutation(({ input }) => createVideo(input)),

    update: adminProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        videoUrl: z.string().optional(),
        thumbnailUrl: z.string().optional(),
        displayOrder: z.number().optional(),
        isActive: z.enum(["true", "false"]).optional(),
      }))
      .mutation(({ input }) => {
        const { id, ...updates } = input;
        return updateVideo(id, updates);
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => deleteVideo(input.id)),
  }),
});

export type AppRouter = typeof appRouter;
