import { eq, or, like } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, products, InsertProduct, jobs, InsertJob, jobApplications, InsertJobApplication, companySettings, InsertCompanySettings, CompanySettings, videos, InsertVideo, Video } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Products queries
export async function getAllProducts() {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get products: database not available");
    return [];
  }
  return db.select().from(products).orderBy(products.createdAt);
}

export async function getProductById(id: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get product: database not available");
    return undefined;
  }
  const result = await db.select().from(products).where(eq(products.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getProductsByCategory(category: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get products: database not available");
    return [];
  }
  return db.select().from(products).where(eq(products.category, category)).orderBy(products.createdAt);
}

export async function searchProducts(query: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot search products: database not available");
    return [];
  }
  return db.select().from(products).where(
    or(
      like(products.name, `%${query}%`),
      like(products.description, `%${query}%`)
    )
  ).orderBy(products.createdAt);
}

export async function createProduct(product: InsertProduct) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot create product: database not available");
    return undefined;
  }
  const result = await db.insert(products).values(product);
  return result;
}

export async function updateProduct(id: number, updates: Partial<InsertProduct>) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update product: database not available");
    return undefined;
  }
  return db.update(products).set(updates).where(eq(products.id, id));
}

export async function deleteProduct(id: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot delete product: database not available");
    return undefined;
  }
  return db.delete(products).where(eq(products.id, id));
}

// Jobs queries
export async function getAllJobs() {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get jobs: database not available");
    return [];
  }
  return db.select().from(jobs).orderBy(jobs.createdAt);
}

export async function getJobById(id: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get job: database not available");
    return undefined;
  }
  const result = await db.select().from(jobs).where(eq(jobs.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getOpenJobs() {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get jobs: database not available");
    return [];
  }
  return db.select().from(jobs).where(eq(jobs.status, "Open")).orderBy(jobs.createdAt);
}

export async function searchJobs(query: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot search jobs: database not available");
    return [];
  }
  return db.select().from(jobs).where(
    or(
      like(jobs.title, `%${query}%`),
      like(jobs.description, `%${query}%`),
      like(jobs.department, `%${query}%`)
    )
  ).orderBy(jobs.createdAt);
}

export async function createJob(job: InsertJob) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot create job: database not available");
    return undefined;
  }
  const result = await db.insert(jobs).values(job);
  return result;
}

export async function updateJob(id: number, updates: Partial<InsertJob>) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update job: database not available");
    return undefined;
  }
  return db.update(jobs).set(updates).where(eq(jobs.id, id));
}

export async function deleteJob(id: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot delete job: database not available");
    return undefined;
  }
  return db.delete(jobs).where(eq(jobs.id, id));
}

// Job Applications queries
export async function createJobApplication(application: InsertJobApplication) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot create application: database not available");
    return undefined;
  }
  const result = await db.insert(jobApplications).values(application);
  return result;
}

export async function getApplicationsByJobId(jobId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get applications: database not available");
    return [];
  }
  return db.select().from(jobApplications).where(eq(jobApplications.jobId, jobId)).orderBy(jobApplications.createdAt);
}

export async function updateJobApplication(id: number, updates: Partial<InsertJobApplication>) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update application: database not available");
    return undefined;
  }
  return db.update(jobApplications).set(updates).where(eq(jobApplications.id, id));
}

// Company Settings queries
export async function getCompanySettings(): Promise<CompanySettings | undefined> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get company settings: database not available");
    return undefined;
  }
  const result = await db.select().from(companySettings).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateCompanySettings(updates: Partial<InsertCompanySettings>) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update company settings: database not available");
    return undefined;
  }
  return db.update(companySettings).set(updates).where(eq(companySettings.id, 1));
}

// Video queries
export async function getVideos() {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get videos: database not available");
    return [];
  }
  return db.select().from(videos).where(eq(videos.isActive, "true")).orderBy(videos.displayOrder);
}

export async function getAllVideos() {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get videos: database not available");
    return [];
  }
  return db.select().from(videos).orderBy(videos.displayOrder);
}

export async function createVideo(video: InsertVideo) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot create video: database not available");
    return undefined;
  }
  const result = await db.insert(videos).values(video);
  return result;
}

export async function updateVideo(id: number, updates: Partial<InsertVideo>) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update video: database not available");
    return undefined;
  }
  return db.update(videos).set(updates).where(eq(videos.id, id));
}

export async function deleteVideo(id: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot delete video: database not available");
    return undefined;
  }
  return db.delete(videos).where(eq(videos.id, id));
}
