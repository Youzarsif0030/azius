CREATE TABLE `job_applications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`jobId` int NOT NULL,
	`userId` int NOT NULL,
	`fullName` varchar(255) NOT NULL,
	`email` varchar(320) NOT NULL,
	`phone` varchar(20) NOT NULL,
	`resume` text,
	`coverLetter` text,
	`status` enum('Applied','Reviewing','Shortlisted','Rejected','Accepted') NOT NULL DEFAULT 'Applied',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `job_applications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `jobs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text NOT NULL,
	`department` varchar(100) NOT NULL,
	`location` varchar(255) NOT NULL,
	`salary` varchar(100),
	`jobType` enum('Full-time','Part-time','Contract','Internship') NOT NULL,
	`experience` varchar(100),
	`qualifications` text,
	`responsibilities` text,
	`status` enum('Open','Closed','On Hold') NOT NULL DEFAULT 'Open',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `jobs_id` PRIMARY KEY(`id`)
);
