import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ProductSlideshow from "@/components/ProductSlideshow";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Pill, Shield, Zap } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Spinner } from "@/components/ui/spinner";

export default function Home() {
  const { data: products, isLoading } = trpc.products.list.useQuery();
  const { data: videos = [] } = trpc.videos.list.useQuery();

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Header />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative bg-gradient-to-r from-blue-900 via-blue-800 to-blue-700 text-white py-20 md:py-32">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <h1 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">
                  Azius Pharma Pvt. Ltd.
                </h1>
                <p className="text-xl text-blue-100 mb-8 leading-relaxed">
                  Delivering excellence in pharmaceutical innovation and healthcare solutions. Trusted by healthcare professionals worldwide.
                </p>
                <div className="flex gap-4">
                  <Link href="/products">
                    <Button size="lg" className="bg-white text-blue-900 hover:bg-gray-100">
                      Explore Products
                    </Button>
                  </Link>
                  <Link href="/contact">
                    <Button size="lg" variant="outline" className="border-white text-white hover:bg-blue-800">
                      Get in Touch
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="hidden md:flex justify-center">
                {videos && videos.length > 0 ? (
                  <div className="w-full rounded-lg overflow-hidden shadow-xl">
                    <video
                      src={videos[0].videoUrl}
                      controls
                      className="w-full h-auto"
                      poster={videos[0].thumbnailUrl || undefined}
                    />
                  </div>
                ) : (
                  <div className="w-full h-64 bg-blue-600 rounded-lg flex items-center justify-center">
                    <Pill size={120} className="text-blue-300" />
                  </div>
                )}
              </div>
            </div>
          </div>
        </section>

        {/* Product Slideshow */}
        {isLoading ? (
          <section className="py-16 md:py-24 bg-gradient-to-br from-blue-50 to-white flex items-center justify-center">
            <Spinner />
          </section>
        ) : products && products.length > 0 ? (
          <ProductSlideshow products={products} />
        ) : null}

        {/* Highlights Section */}
        <section className="py-16 md:py-24 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-gray-900">
              Why Choose Azius Pharma?
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Feature 1 */}
              <div className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition">
                <div className="flex justify-center mb-4">
                  <Shield size={48} className="text-blue-900" />
                </div>
                <h3 className="text-xl font-bold text-center mb-4 text-gray-900">
                  Quality Assured
                </h3>
                <p className="text-gray-600 text-center">
                  All products meet international standards and rigorous quality control measures.
                </p>
              </div>

              {/* Feature 2 */}
              <div className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition">
                <div className="flex justify-center mb-4">
                  <Zap size={48} className="text-blue-900" />
                </div>
                <h3 className="text-xl font-bold text-center mb-4 text-gray-900">
                  Innovation First
                </h3>
                <p className="text-gray-600 text-center">
                  Continuous research and development to bring cutting-edge solutions to market.
                </p>
              </div>

              {/* Feature 3 */}
              <div className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition">
                <div className="flex justify-center mb-4">
                  <Pill size={48} className="text-blue-900" />
                </div>
                <h3 className="text-xl font-bold text-center mb-4 text-gray-900">
                  Patient Focused
                </h3>
                <p className="text-gray-600 text-center">
                  Dedicated to improving healthcare outcomes and patient well-being globally.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 md:py-24 bg-blue-900 text-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Discover Our Product Range
            </h2>
            <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
              Browse our comprehensive catalog of pharmaceutical products designed to meet diverse healthcare needs.
            </p>
            <Link href="/products">
              <Button size="lg" className="bg-white text-blue-900 hover:bg-gray-100">
                View All Products
              </Button>
            </Link>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
