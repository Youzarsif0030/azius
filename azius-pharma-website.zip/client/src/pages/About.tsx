import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Award, Target, Users } from "lucide-react";

export default function About() {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Header />

      <main className="flex-1">
        {/* Page Header */}
        <section className="bg-gradient-to-r from-blue-900 to-blue-800 text-white py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h1 className="text-4xl font-bold mb-2">About Us</h1>
            <p className="text-blue-100">
              Learn more about Azius Pharma Pvt. Ltd. and our mission
            </p>
          </div>
        </section>

        {/* Company Overview */}
        <section className="py-16 md:py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                  Who We Are
                </h2>
                <p className="text-gray-600 text-lg mb-4 leading-relaxed">
                  Azius Pharma Pvt. Ltd. is a leading pharmaceutical company dedicated to developing and delivering high-quality pharmaceutical products that improve healthcare outcomes across the globe.
                </p>
                <p className="text-gray-600 text-lg mb-4 leading-relaxed">
                  With years of experience in the pharmaceutical industry, we have established ourselves as a trusted partner for healthcare professionals and patients alike.
                </p>
                <p className="text-gray-600 text-lg leading-relaxed">
                  Our commitment to excellence, innovation, and patient care drives everything we do.
                </p>
              </div>
              <div className="bg-gradient-to-br from-blue-900 to-blue-700 rounded-lg p-12 text-white">
                <h3 className="text-2xl font-bold mb-6">Our Commitment</h3>
                <ul className="space-y-4">
                  <li className="flex gap-3">
                    <span className="text-blue-300 font-bold">✓</span>
                    <span>Delivering quality pharmaceutical products</span>
                  </li>
                  <li className="flex gap-3">
                    <span className="text-blue-300 font-bold">✓</span>
                    <span>Continuous research and development</span>
                  </li>
                  <li className="flex gap-3">
                    <span className="text-blue-300 font-bold">✓</span>
                    <span>Maintaining highest ethical standards</span>
                  </li>
                  <li className="flex gap-3">
                    <span className="text-blue-300 font-bold">✓</span>
                    <span>Supporting healthcare professionals</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* Mission, Vision, Values */}
        <section className="py-16 md:py-24 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl md:text-4xl font-bold text-center text-gray-900 mb-12">
              Our Mission, Vision & Values
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Mission */}
              <div className="bg-white p-8 rounded-lg shadow-md">
                <div className="flex justify-center mb-4">
                  <Target size={48} className="text-blue-900" />
                </div>
                <h3 className="text-2xl font-bold text-center text-gray-900 mb-4">
                  Our Mission
                </h3>
                <p className="text-gray-600 text-center leading-relaxed">
                  To develop and deliver innovative pharmaceutical products that address unmet healthcare needs and improve the quality of life for patients worldwide.
                </p>
              </div>

              {/* Vision */}
              <div className="bg-white p-8 rounded-lg shadow-md">
                <div className="flex justify-center mb-4">
                  <Award size={48} className="text-blue-900" />
                </div>
                <h3 className="text-2xl font-bold text-center text-gray-900 mb-4">
                  Our Vision
                </h3>
                <p className="text-gray-600 text-center leading-relaxed">
                  To be a globally recognized pharmaceutical company known for excellence, innovation, and commitment to patient care and healthcare advancement.
                </p>
              </div>

              {/* Values */}
              <div className="bg-white p-8 rounded-lg shadow-md">
                <div className="flex justify-center mb-4">
                  <Users size={48} className="text-blue-900" />
                </div>
                <h3 className="text-2xl font-bold text-center text-gray-900 mb-4">
                  Our Values
                </h3>
                <p className="text-gray-600 text-center leading-relaxed">
                  Integrity, innovation, quality, patient focus, and social responsibility guide our decisions and actions every day.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Team Section */}
        <section className="py-16 md:py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl md:text-4xl font-bold text-center text-gray-900 mb-12">
              Why Choose Azius Pharma?
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-900 text-white">
                    <span className="text-xl font-bold">1</span>
                  </div>
                </div>
                <div>
                  <h3 className="text-lg font-bold text-gray-900 mb-2">
                    Quality Assurance
                  </h3>
                  <p className="text-gray-600">
                    All our products undergo rigorous testing and comply with international quality standards.
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-900 text-white">
                    <span className="text-xl font-bold">2</span>
                  </div>
                </div>
                <div>
                  <h3 className="text-lg font-bold text-gray-900 mb-2">
                    Innovation
                  </h3>
                  <p className="text-gray-600">
                    We invest heavily in research and development to bring cutting-edge solutions to market.
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-900 text-white">
                    <span className="text-xl font-bold">3</span>
                  </div>
                </div>
                <div>
                  <h3 className="text-lg font-bold text-gray-900 mb-2">
                    Expertise
                  </h3>
                  <p className="text-gray-600">
                    Our team brings decades of combined experience in pharmaceutical development and healthcare.
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-900 text-white">
                    <span className="text-xl font-bold">4</span>
                  </div>
                </div>
                <div>
                  <h3 className="text-lg font-bold text-gray-900 mb-2">
                    Global Reach
                  </h3>
                  <p className="text-gray-600">
                    We serve healthcare professionals and patients across multiple countries and regions.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
