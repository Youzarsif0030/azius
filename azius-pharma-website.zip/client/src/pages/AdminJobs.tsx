import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Card } from "@/components/ui/card";
import { Spinner } from "@/components/ui/spinner";
import { Trash2, Edit2, Plus } from "lucide-react";
import { toast } from "sonner";

export default function AdminJobs() {
  const [isOpen, setIsOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    department: "",
    location: "",
    salary: "",
    jobType: "Full-time" as const,
    experience: "",
    qualifications: "",
    responsibilities: "",
    status: "Open" as const,
  });

  const { data: jobs, isLoading, refetch } = trpc.jobs.list.useQuery();
  const createMutation = trpc.jobs.create.useMutation();
  const updateMutation = trpc.jobs.update.useMutation();
  const deleteMutation = trpc.jobs.delete.useMutation();

  const handleSubmit = async () => {
    if (!formData.title || !formData.description || !formData.department || !formData.location) {
      toast.error("Please fill in all required fields");
      return;
    }

    try {
      if (editingId) {
        await updateMutation.mutateAsync({
          id: editingId,
          ...formData,
        });
        toast.success("Job updated successfully");
      } else {
        await createMutation.mutateAsync(formData);
        toast.success("Job created successfully");
      }
      setIsOpen(false);
      setEditingId(null);
      setFormData({
        title: "",
        description: "",
        department: "",
        location: "",
        salary: "",
        jobType: "Full-time",
        experience: "",
        qualifications: "",
        responsibilities: "",
        status: "Open",
      });
      refetch();
    } catch (error) {
      toast.error("Failed to save job");
    }
  };

  const handleEdit = (job: any) => {
    setFormData(job);
    setEditingId(job.id);
    setIsOpen(true);
  };

  const handleDelete = async (id: number) => {
    if (confirm("Are you sure you want to delete this job?")) {
      try {
        await deleteMutation.mutateAsync({ id });
        toast.success("Job deleted successfully");
        refetch();
      } catch (error) {
        toast.error("Failed to delete job");
      }
    }
  };

  const handleClose = () => {
    setIsOpen(false);
    setEditingId(null);
    setFormData({
      title: "",
      description: "",
      department: "",
      location: "",
      salary: "",
      jobType: "Full-time",
      experience: "",
      qualifications: "",
      responsibilities: "",
      status: "Open",
    });
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Spinner />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">Job Vacancies</h1>
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button className="bg-blue-900 hover:bg-blue-800 text-white">
              <Plus size={20} className="mr-2" />
              Add New Job
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingId ? "Edit Job" : "Create New Job"}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Job Title *</label>
                <Input
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="e.g., Senior Pharmacist"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description *</label>
                <Textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Job description..."
                  rows={4}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Department *</label>
                  <Input
                    value={formData.department}
                    onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                    placeholder="e.g., Research & Development"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Location *</label>
                  <Input
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    placeholder="e.g., Mumbai, India"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Salary</label>
                  <Input
                    value={formData.salary}
                    onChange={(e) => setFormData({ ...formData, salary: e.target.value })}
                    placeholder="e.g., ₹50,000 - ₹80,000"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Job Type</label>
                  <Select value={formData.jobType} onValueChange={(value: any) => setFormData({ ...formData, jobType: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Full-time">Full-time</SelectItem>
                      <SelectItem value="Part-time">Part-time</SelectItem>
                      <SelectItem value="Contract">Contract</SelectItem>
                      <SelectItem value="Internship">Internship</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Experience Required</label>
                <Input
                  value={formData.experience}
                  onChange={(e) => setFormData({ ...formData, experience: e.target.value })}
                  placeholder="e.g., 3-5 years"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Qualifications</label>
                <Textarea
                  value={formData.qualifications}
                  onChange={(e) => setFormData({ ...formData, qualifications: e.target.value })}
                  placeholder="Required qualifications..."
                  rows={3}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Responsibilities</label>
                <Textarea
                  value={formData.responsibilities}
                  onChange={(e) => setFormData({ ...formData, responsibilities: e.target.value })}
                  placeholder="Key responsibilities..."
                  rows={3}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                <Select value={formData.status} onValueChange={(value: any) => setFormData({ ...formData, status: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Open">Open</SelectItem>
                    <SelectItem value="Closed">Closed</SelectItem>
                    <SelectItem value="On Hold">On Hold</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex gap-2 pt-4">
                <Button onClick={handleSubmit} className="bg-blue-900 hover:bg-blue-800 text-white flex-1">
                  {editingId ? "Update Job" : "Create Job"}
                </Button>
                <Button onClick={handleClose} variant="outline" className="flex-1">
                  Cancel
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4">
        {jobs && jobs.length > 0 ? (
          jobs.map((job: any) => (
            <Card key={job.id} className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-gray-900">{job.title}</h3>
                  <p className="text-gray-600">{job.department} • {job.location}</p>
                  <div className="flex gap-2 mt-2">
                    <span className="inline-block px-2 py-1 bg-blue-100 text-blue-900 text-xs font-semibold rounded">
                      {job.jobType}
                    </span>
                    <span className={`inline-block px-2 py-1 text-xs font-semibold rounded ${
                      job.status === "Open" ? "bg-green-100 text-green-900" :
                      job.status === "Closed" ? "bg-red-100 text-red-900" :
                      "bg-yellow-100 text-yellow-900"
                    }`}>
                      {job.status}
                    </span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    onClick={() => handleEdit(job)}
                    variant="outline"
                    size="sm"
                    className="text-blue-900 border-blue-900"
                  >
                    <Edit2 size={16} />
                  </Button>
                  <Button
                    onClick={() => handleDelete(job.id)}
                    variant="outline"
                    size="sm"
                    className="text-red-900 border-red-900"
                  >
                    <Trash2 size={16} />
                  </Button>
                </div>
              </div>
              <p className="text-gray-700 mb-3">{job.description}</p>
              {job.salary && <p className="text-sm text-gray-600">Salary: {job.salary}</p>}
              {job.experience && <p className="text-sm text-gray-600">Experience: {job.experience}</p>}
            </Card>
          ))
        ) : (
          <Card className="p-6 text-center">
            <p className="text-gray-600">No jobs posted yet. Create your first job posting!</p>
          </Card>
        )}
      </div>
    </div>
  );
}
