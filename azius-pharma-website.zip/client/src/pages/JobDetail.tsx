import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useRoute, Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { Spinner } from "@/components/ui/spinner";
import { useState } from "react";
import { MapPin, Briefcase, DollarSign, Clock } from "lucide-react";
import { toast } from "sonner";

export default function JobDetail() {
  const [, params] = useRoute("/jobs/:id");
  const jobId = params?.id ? parseInt(params.id) : null;
  const [isApplyOpen, setIsApplyOpen] = useState(false);
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    resume: "",
    coverLetter: "",
  });

  const { data: job, isLoading } = trpc.jobs.getById.useQuery(
    { id: jobId! },
    { enabled: !!jobId }
  );

  const submitApplicationMutation = trpc.jobs.submitApplication.useMutation();

  const handleSubmitApplication = async () => {
    if (!formData.fullName || !formData.email || !formData.phone) {
      toast.error("Please fill in all required fields");
      return;
    }

    try {
      await submitApplicationMutation.mutateAsync({
        jobId: jobId!,
        ...formData,
      });
      toast.success("Application submitted successfully!");
      setIsApplyOpen(false);
      setFormData({
        fullName: "",
        email: "",
        phone: "",
        resume: "",
        coverLetter: "",
      });
    } catch (error) {
      toast.error("Failed to submit application");
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex justify-center items-center">
          <Spinner />
        </main>
        <Footer />
      </div>
    );
  }

  if (!job) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
            <Card className="p-12 text-center">
              <p className="text-gray-600 text-lg mb-6">Job not found</p>
              <Link href="/jobs">
                <Button className="bg-blue-900 hover:bg-blue-800 text-white">
                  Back to Jobs
                </Button>
              </Link>
            </Card>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Header />

      <main className="flex-1">
        {/* Breadcrumb */}
        <section className="bg-gray-50 py-4">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <Link href="/jobs">
              <span className="text-blue-900 hover:underline cursor-pointer">← Back to Jobs</span>
            </Link>
          </div>
        </section>

        {/* Job Details */}
        <section className="py-16 md:py-24">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="mb-8">
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">{job.title}</h1>
              <div className="flex flex-wrap gap-4 mb-6">
                <div className="flex items-center gap-2 text-gray-600">
                  <MapPin size={20} className="text-blue-900" />
                  <span>{job.location}</span>
                </div>
                <div className="flex items-center gap-2 text-gray-600">
                  <Briefcase size={20} className="text-blue-900" />
                  <span>{job.department}</span>
                </div>
                {job.salary && (
                  <div className="flex items-center gap-2 text-gray-600">
                    <DollarSign size={20} className="text-blue-900" />
                    <span>{job.salary}</span>
                  </div>
                )}
              </div>
              <div className="flex gap-2 mb-6">
                <span className="inline-block px-4 py-2 bg-blue-100 text-blue-900 font-semibold rounded-full">
                  {job.jobType}
                </span>
                {job.experience && (
                  <span className="inline-block px-4 py-2 bg-gray-100 text-gray-900 font-semibold rounded-full">
                    {job.experience}
                  </span>
                )}
              </div>
            </div>

            {/* Job Description */}
            <Card className="p-8 mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Job Description</h2>
              <p className="text-gray-700 leading-relaxed mb-6">{job.description}</p>

              {job.responsibilities && (
                <div className="mb-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-3">Key Responsibilities</h3>
                  <p className="text-gray-700 leading-relaxed whitespace-pre-wrap">{job.responsibilities}</p>
                </div>
              )}

              {job.qualifications && (
                <div className="mb-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-3">Required Qualifications</h3>
                  <p className="text-gray-700 leading-relaxed whitespace-pre-wrap">{job.qualifications}</p>
                </div>
              )}

              <div className="border-t pt-6">
                <Dialog open={isApplyOpen} onOpenChange={setIsApplyOpen}>
                  <DialogTrigger asChild>
                    <Button className="bg-blue-900 hover:bg-blue-800 text-white px-8 py-3 text-lg">
                      Apply Now
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>Apply for {job.title}</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Full Name *</label>
                        <Input
                          value={formData.fullName}
                          onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                          placeholder="Your full name"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Email *</label>
                        <Input
                          type="email"
                          value={formData.email}
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          placeholder="your.email@example.com"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Phone *</label>
                        <Input
                          value={formData.phone}
                          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                          placeholder="+91 XXXXX XXXXX"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Resume / CV</label>
                        <Textarea
                          value={formData.resume}
                          onChange={(e) => setFormData({ ...formData, resume: e.target.value })}
                          placeholder="Paste your resume or CV content here..."
                          rows={4}
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Cover Letter</label>
                        <Textarea
                          value={formData.coverLetter}
                          onChange={(e) => setFormData({ ...formData, coverLetter: e.target.value })}
                          placeholder="Tell us why you're interested in this position..."
                          rows={4}
                        />
                      </div>

                      <div className="flex gap-2 pt-4">
                        <Button
                          onClick={handleSubmitApplication}
                          className="bg-blue-900 hover:bg-blue-800 text-white flex-1"
                          disabled={submitApplicationMutation.isPending}
                        >
                          {submitApplicationMutation.isPending ? "Submitting..." : "Submit Application"}
                        </Button>
                        <Button
                          onClick={() => setIsApplyOpen(false)}
                          variant="outline"
                          className="flex-1"
                        >
                          Cancel
                        </Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </Card>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
