import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Link, useParams } from "wouter";
import { trpc } from "@/lib/trpc";
import { Loader2, ArrowLeft } from "lucide-react";

export default function ProductDetail() {
  const params = useParams();
  const productId = params.id ? parseInt(params.id) : null;

  const { data: product, isLoading } = trpc.products.getById.useQuery(
    { id: productId! },
    { enabled: !!productId }
  );

  if (!productId) {
    return (
      <div className="min-h-screen flex flex-col bg-white">
        <Header />
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <p className="text-gray-600 text-lg mb-4">Product not found</p>
            <Link href="/products">
              <Button>Back to Products</Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Header />

      <main className="flex-1">
        {/* Breadcrumb */}
        <section className="bg-gray-50 py-4">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center gap-2">
              <Link href="/products" className="text-blue-900 hover:underline flex items-center gap-1">
                <ArrowLeft size={16} />
                Products
              </Link>
              <span className="text-gray-400">/</span>
              <span className="text-gray-600">Product Details</span>
            </div>
          </div>
        </section>

        {/* Product Details */}
        <section className="py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {isLoading ? (
              <div className="flex justify-center items-center py-12">
                <Loader2 className="animate-spin text-blue-900" size={32} />
              </div>
            ) : !product ? (
              <div className="text-center py-12">
                <p className="text-gray-600 text-lg mb-4">Product not found</p>
                <Link href="/products">
                  <Button>Back to Products</Button>
                </Link>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                {/* Product Image */}
                <div className="flex items-center justify-center">
                  <div className="w-full bg-gray-100 rounded-lg overflow-hidden flex items-center justify-center" style={{ minHeight: '500px' }}>
                    {product.imageUrl ? (
                      <img
                        src={product.imageUrl}
                        alt={product.name}
                        className="w-auto h-auto max-w-full max-h-full object-contain"
                      />
                    ) : (
                      <div className="text-gray-400 text-center">
                        <p className="text-lg">No image available</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Product Information */}
                <div>
                  <div className="mb-4">
                    <span className="inline-block px-3 py-1 bg-blue-100 text-blue-900 rounded-full text-sm font-semibold">
                      {product.category}
                    </span>
                  </div>

                  <h1 className="text-4xl font-bold text-gray-900 mb-4">
                    {product.name}
                  </h1>

                  <div className="border-t border-b border-gray-200 py-6 mb-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-3">
                      Description
                    </h3>
                    <p className="text-gray-600 leading-relaxed text-lg">
                      {product.description || "No description available"}
                    </p>
                  </div>

                  <div className="bg-gray-50 p-6 rounded-lg mb-6">
                    <h3 className="font-semibold text-gray-900 mb-4">Product Information</h3>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Product ID:</span>
                        <span className="font-medium text-gray-900">#{product.id}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Category:</span>
                        <span className="font-medium text-gray-900">{product.category}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Added:</span>
                        <span className="font-medium text-gray-900">
                          {new Date(product.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <Button size="lg" className="flex-1 bg-blue-900 hover:bg-blue-800">
                      Contact for Inquiry
                    </Button>
                    <Link href="/products" className="flex-1">
                      <Button size="lg" variant="outline" className="w-full">
                        Back to Products
                      </Button>
                    </Link>
                  </div>
                </div>
              </div>
            )}
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
