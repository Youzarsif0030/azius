import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";
import { Loader2, Plus, Edit2, Trash2, X } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";

export default function AdminVideos() {
  const { user } = useAuth();
  const [isAddingVideo, setIsAddingVideo] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);

  // Form state
  const [formData, setFormData] = useState<{
    title: string;
    description: string;
    videoUrl: string;
    displayOrder: number;
    isActive: "true" | "false";
  }>({
    title: "",
    description: "",
    videoUrl: "",
    displayOrder: 0,
    isActive: "true",
  });

  // Fetch videos
  const { data: videos = [], isLoading, refetch } = trpc.videos.all.useQuery();

  // Mutations
  const createMutation = trpc.videos.create.useMutation({
    onSuccess: () => {
      toast.success("Video added successfully");
      setFormData({
        title: "",
        description: "",
        videoUrl: "",
        displayOrder: 0,
        isActive: "true",
      });
      setIsAddingVideo(false);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to add video");
    },
  });

  const updateMutation = trpc.videos.update.useMutation({
    onSuccess: () => {
      toast.success("Video updated successfully");
      setEditingId(null);
      setFormData({
        title: "",
        description: "",
        videoUrl: "",
        displayOrder: 0,
        isActive: "true",
      });
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to update video");
    },
  });

  const deleteMutation = trpc.videos.delete.useMutation({
    onSuccess: () => {
      toast.success("Video deleted successfully");
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to delete video");
    },
  });

  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    if (name === "displayOrder") {
      setFormData(prev => ({ ...prev, [name]: parseInt(value) || 0 }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.title || !formData.videoUrl) {
      toast.error("Title and video URL are required");
      return;
    }

    if (editingId) {
      updateMutation.mutate({
        id: editingId,
        ...formData,
      } as any);
    } else {
      createMutation.mutate(formData as any);
    }
  };

  const handleEdit = (video: typeof videos[0]) => {
    setEditingId(video.id);
    setFormData({
      title: video.title,
      description: video.description || "",
      videoUrl: video.videoUrl,
      displayOrder: video.displayOrder,
      isActive: video.isActive,
    });
  };

  const handleCancel = () => {
    setEditingId(null);
    setFormData({
      title: "",
      description: "",
      videoUrl: "",
      displayOrder: 0,
      isActive: "true",
    });
    setIsAddingVideo(false);
  };

  if (!user || user.role !== "admin") {
    return <div className="p-8 text-center">Access denied</div>;
  }

  return (
    <div>
      <main className="flex-1">
        {/* Page Header */}
        <section className="bg-gradient-to-r from-blue-900 to-blue-800 text-white py-8">
          <div className="container mx-auto px-4">
            <h1 className="text-4xl font-bold mb-2">Admin Panel - Videos</h1>
            <p className="text-blue-100">Manage promotional videos</p>
          </div>
        </section>

        {/* Add Video Form */}
        <section className="py-8 px-4">
          <div className="container mx-auto max-w-2xl">
            <div className="bg-white rounded-lg shadow-md p-6 mb-8">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">
                  {editingId ? "Edit Video" : "Add New Video"}
                </h2>
                {(isAddingVideo || editingId) && (
                  <button
                    onClick={handleCancel}
                    className="text-gray-500 hover:text-gray-700"
                  >
                    <X size={24} />
                  </button>
                )}
              </div>

              {(isAddingVideo || editingId) && (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Video Title *
                      </label>
                      <Input
                        type="text"
                        name="title"
                        value={formData.title}
                        onChange={handleFormChange}
                        placeholder="Enter video title"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Display Order
                      </label>
                      <Input
                        type="number"
                        name="displayOrder"
                        value={formData.displayOrder}
                        onChange={handleFormChange}
                        placeholder="0"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Video URL *
                    </label>
                    <Input
                      type="text"
                      name="videoUrl"
                      value={formData.videoUrl}
                      onChange={handleFormChange}
                      placeholder="e.g., /manus-storage/video.mp4"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Description
                    </label>
                    <Textarea
                      name="description"
                      value={formData.description}
                      onChange={handleFormChange}
                      placeholder="Enter video description"
                      rows={3}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Status
                    </label>
                    <select
                      name="isActive"
                      value={formData.isActive}
                      onChange={handleFormChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    >
                      <option value="true">Active</option>
                      <option value="false">Inactive</option>
                    </select>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      type="submit"
                      disabled={createMutation.isPending || updateMutation.isPending}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      {createMutation.isPending || updateMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Saving...
                        </>
                      ) : editingId ? (
                        "Update Video"
                      ) : (
                        "Add Video"
                      )}
                    </Button>
                    <Button
                      type="button"
                      onClick={handleCancel}
                      variant="outline"
                    >
                      Cancel
                    </Button>
                  </div>
                </form>
              )}

              {!isAddingVideo && !editingId && (
                <Button
                  onClick={() => setIsAddingVideo(true)}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Add Video
                </Button>
              )}
            </div>

            {/* Videos List */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-2xl font-bold mb-6">
                Videos ({videos.length})
              </h2>

              {isLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin" />
                </div>
              ) : videos.length === 0 ? (
                <p className="text-gray-500 text-center py-8">
                  No videos added yet
                </p>
              ) : (
                <div className="space-y-4">
                  {videos.map((video) => (
                    <div
                      key={video.id}
                      className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
                    >
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <h3 className="text-lg font-semibold mb-2">
                            {video.title}
                          </h3>
                          {video.description && (
                            <p className="text-gray-600 mb-2 text-sm">
                              {video.description}
                            </p>
                          )}
                          <div className="flex gap-4 text-sm text-gray-500">
                            <span>Order: {video.displayOrder}</span>
                            <span>
                              Status:{" "}
                              <span
                                className={
                                  video.isActive === "true"
                                    ? "text-green-600"
                                    : "text-red-600"
                                }
                              >
                                {video.isActive === "true"
                                  ? "Active"
                                  : "Inactive"}
                              </span>
                            </span>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleEdit(video)}
                            className="p-2 text-blue-600 hover:bg-blue-50 rounded"
                          >
                            <Edit2 size={18} />
                          </button>
                          <button
                            onClick={() => {
                              if (
                                confirm(
                                  "Are you sure you want to delete this video?"
                                )
                              ) {
                                deleteMutation.mutate({ id: video.id });
                              }
                            }}
                            className="p-2 text-red-600 hover:bg-red-50 rounded"
                          >
                            <Trash2 size={18} />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
