import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { Spinner } from "@/components/ui/spinner";
import { useState } from "react";
import { MapPin, Briefcase, DollarSign, Search } from "lucide-react";

export default function Jobs() {
  const [searchQuery, setSearchQuery] = useState("");
  const { data: jobs, isLoading } = trpc.jobs.getOpen.useQuery();

  const filteredJobs = jobs?.filter((job: any) =>
    job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    job.department.toLowerCase().includes(searchQuery.toLowerCase()) ||
    job.location.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Header />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-blue-900 via-blue-800 to-blue-700 text-white py-16 md:py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Join Our Team</h1>
            <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
              Explore exciting career opportunities at Azius Pharma Pvt. Ltd. and be part of our mission to deliver quality healthcare solutions.
            </p>
          </div>
        </section>

        {/* Search Section */}
        <section className="py-12 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="relative">
              <Search className="absolute left-3 top-3 text-gray-400" size={20} />
              <Input
                type="text"
                placeholder="Search by job title, department, or location..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 py-3 text-lg"
              />
            </div>
          </div>
        </section>

        {/* Jobs Listing */}
        <section className="py-16 md:py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {isLoading ? (
              <div className="flex justify-center items-center min-h-96">
                <Spinner />
              </div>
            ) : filteredJobs.length > 0 ? (
              <div className="grid gap-6">
                {filteredJobs.map((job: any) => (
                  <Card key={job.id} className="p-6 hover:shadow-lg transition">
                    <div className="flex justify-between items-start mb-4">
                      <div className="flex-1">
                        <h3 className="text-2xl font-bold text-gray-900 mb-2">{job.title}</h3>
                        <div className="flex flex-wrap gap-4 text-gray-600 mb-4">
                          <div className="flex items-center gap-2">
                            <MapPin size={18} className="text-blue-900" />
                            <span>{job.location}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Briefcase size={18} className="text-blue-900" />
                            <span>{job.department}</span>
                          </div>
                          {job.salary && (
                            <div className="flex items-center gap-2">
                              <DollarSign size={18} className="text-blue-900" />
                              <span>{job.salary}</span>
                            </div>
                          )}
                        </div>
                        <div className="flex gap-2 mb-4">
                          <span className="inline-block px-3 py-1 bg-blue-100 text-blue-900 text-sm font-semibold rounded-full">
                            {job.jobType}
                          </span>
                          {job.experience && (
                            <span className="inline-block px-3 py-1 bg-gray-100 text-gray-900 text-sm font-semibold rounded-full">
                              {job.experience}
                            </span>
                          )}
                        </div>
                      </div>
                      <Link href={`/jobs/${job.id}`}>
                        <Button className="bg-blue-900 hover:bg-blue-800 text-white">
                          View Details
                        </Button>
                      </Link>
                    </div>
                    <p className="text-gray-700 line-clamp-2">{job.description}</p>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="p-12 text-center">
                <p className="text-gray-600 text-lg">
                  {searchQuery ? "No jobs match your search. Try different keywords." : "No open positions available at the moment. Please check back later."}
                </p>
              </Card>
            )}
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
