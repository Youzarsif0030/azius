import { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";

interface Product {
  id: number;
  name: string;
  description: string | null;
  category: string;
  imageUrl: string | null;
  createdAt: Date;
  updatedAt: Date;
}

interface ProductSlideshowProps {
  products: Product[];
}

export default function ProductSlideshow({ products }: ProductSlideshowProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [autoPlay, setAutoPlay] = useState(true);

  useEffect(() => {
    if (!autoPlay || products.length === 0) return;

    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % products.length);
    }, 5000); // Change slide every 5 seconds

    return () => clearInterval(timer);
  }, [autoPlay, products.length]);

  if (products.length === 0) {
    return null;
  }

  const currentProduct = products[currentIndex];

  const goToPrevious = () => {
    setCurrentIndex((prev) => (prev - 1 + products.length) % products.length);
    setAutoPlay(false);
  };

  const goToNext = () => {
    setCurrentIndex((prev) => (prev + 1) % products.length);
    setAutoPlay(false);
  };

  const goToSlide = (index: number) => {
    setCurrentIndex(index);
    setAutoPlay(false);
  };

  return (
    <section className="py-16 md:py-24 bg-gradient-to-br from-blue-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-gray-900">
          Featured Products
        </h2>

        <div className="relative bg-white rounded-lg shadow-xl overflow-hidden">
          {/* Main Slide */}
          <div className="relative h-96 md:h-[500px] flex items-center justify-center bg-gray-100">
            {currentProduct.imageUrl ? (
              <img
                src={currentProduct.imageUrl}
                alt={currentProduct.name}
                className="w-auto h-auto max-w-full max-h-full object-contain"
              />
            ) : (
              <div className="flex items-center justify-center w-full h-full bg-gradient-to-br from-blue-100 to-blue-50">
                <div className="text-center">
                  <div className="text-6xl mb-4">💊</div>
                  <p className="text-gray-500 text-lg">Product Image</p>
                </div>
              </div>
            )}

            {/* Navigation Buttons */}
            <button
              onClick={goToPrevious}
              className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white text-blue-900 p-2 rounded-full shadow-lg transition z-10"
              aria-label="Previous slide"
            >
              <ChevronLeft size={24} />
            </button>
            <button
              onClick={goToNext}
              className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white text-blue-900 p-2 rounded-full shadow-lg transition z-10"
              aria-label="Next slide"
            >
              <ChevronRight size={24} />
            </button>
          </div>

          {/* Product Info */}
          <div className="p-8 md:p-12 bg-white">
            <div className="flex items-center justify-between mb-4">
              <span className="inline-block px-3 py-1 bg-blue-100 text-blue-900 rounded-full text-sm font-semibold">
                {currentProduct.category}
              </span>
              <span className="text-gray-500 text-sm">
                {currentIndex + 1} / {products.length}
              </span>
            </div>
            <h3 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">
              {currentProduct.name}
            </h3>
            {currentProduct.description && (
              <p className="text-gray-600 text-lg leading-relaxed mb-6">
                {currentProduct.description}
              </p>
            )}
            <Button className="bg-blue-900 hover:bg-blue-800 text-white">
              View Details
            </Button>
          </div>

          {/* Slide Indicators */}
          <div className="flex justify-center gap-2 p-6 bg-gray-50">
            {products.map((_, index) => (
              <button
                key={index}
                onClick={() => goToSlide(index)}
                className={`h-2 rounded-full transition-all ${
                  index === currentIndex
                    ? "bg-blue-900 w-8"
                    : "bg-gray-300 w-2 hover:bg-gray-400"
                }`}
                aria-label={`Go to slide ${index + 1}`}
              />
            ))}
          </div>
        </div>

        {/* Auto-play Toggle */}
        <div className="flex justify-center mt-6">
          <Button
            onClick={() => setAutoPlay(!autoPlay)}
            variant="outline"
            className="text-blue-900 border-blue-900 hover:bg-blue-50"
          >
            {autoPlay ? "⏸ Pause" : "▶ Play"} Slideshow
          </Button>
        </div>
      </div>
    </section>
  );
}
