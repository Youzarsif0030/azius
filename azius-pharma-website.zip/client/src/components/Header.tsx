import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { getLoginUrl } from "@/const";
import { Link } from "wouter";
import { Menu, X } from "lucide-react";
import { useState } from "react";

export default function Header() {
  const { user, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2">
          <img src="/manus-storage/1000535388-removebg-preview_d3bde2d7.png" alt="Azius Pharma" className="h-12 w-auto" />
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center gap-8">
          <Link href="/" className="text-gray-700 hover:text-blue-900 transition">
            Home
          </Link>
          <Link href="/products" className="text-gray-700 hover:text-blue-900 transition">
            Products
          </Link>
          <Link href="/about" className="text-gray-700 hover:text-blue-900 transition">
            About
          </Link>
          <Link href="/contact" className="text-gray-700 hover:text-blue-900 transition">
            Contact
          </Link>
          <Link href="/jobs" className="text-gray-700 hover:text-blue-900 transition">
            Careers
          </Link>
        </div>

        {/* Auth Section */}
        <div className="hidden md:flex items-center gap-4">
          {user ? (
            <>
              {user.role === 'admin' && (
                <Link href="/admin">
                  <Button variant="outline" size="sm">
                    Admin Panel
                  </Button>
                </Link>
              )}
              <div className="text-sm text-gray-600">{user.name}</div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => logout()}
              >
                Logout
              </Button>
            </>
          ) : (
            <a href={getLoginUrl()}>
              <Button size="sm">
                Login
              </Button>
            </a>
          )}
        </div>

        {/* Mobile Menu Button */}
        <button
          className="md:hidden"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </nav>

      {/* Mobile Navigation */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-200 p-4 space-y-4">
          <Link href="/" className="block text-gray-700 hover:text-blue-900">
            Home
          </Link>
          <Link href="/products" className="block text-gray-700 hover:text-blue-900">
            Products
          </Link>
          <Link href="/about" className="block text-gray-700 hover:text-blue-900">
            About
          </Link>
          <Link href="/contact" className="block text-gray-700 hover:text-blue-900">
            Contact
          </Link>
          <Link href="/jobs" className="block text-gray-700 hover:text-blue-900">
            Careers
          </Link>
          {user && user.role === 'admin' && (
            <Link href="/admin" className="block text-gray-700 hover:text-blue-900">
              Admin Panel
            </Link>
          )}
          <div className="pt-4 border-t border-gray-200">
            {user ? (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => logout()}
                className="w-full"
              >
                Logout
              </Button>
            ) : (
              <a href={getLoginUrl()} className="block">
                <Button size="sm" className="w-full">
                  Login
                </Button>
              </a>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
